from PyQt5 import QtWidgets, QtGui,QtCore
from PyQt5.QtGui import QMovie
import random
import requests
from requests import get
from datetime import  datetime

import pywhatkit as kit
import smtplib
import pyjokes
import wikipedia

import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.uic import loadUiType
import pyttsx3
import speech_recognition as sr
import os
import time
import webbrowser
import datetime


flags = QtCore.Qt.WindowFlags(QtCore.Qt.FramelessWindowHint)

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice',voices[0].id)
engine.setProperty('rate',180)

def speak(audio):
    engine.say(audio)
    engine.runAndWait()


def currenttime():
    now = datetime.now()


    current_time = now.strftime("%H:%M:%S")
    speak(f"current time is : {current_time}")


def googlenews():
    # BBC news api
    main_url = " http://newsapi.org/v2/top-headlines?sources=google-news-in&apiKey=35705d33539c42c0a6afe72c405d6613"

    # fetching data in json format
    open_google_page = requests.get(main_url).json()

    # getting all articles in a string article
    article = open_google_page["articles"]

    # empty list which will
    # contain all trending news
    results = []

    for ar in article:
        results.append(ar["title"])

    for i in range(len(results)):
        # printing all trending news
        print(i + 1, results[i])

    # to read the news out loud for us
    from win32com.client import Dispatch
    speak = Dispatch("SAPI.Spvoice")
    speak.Speak(results)
#
# def wish():


    # hour = int(datetime.now().hour)
    # if hour >= 0 and hour < 12:
    #     print("good morning sir")
    # else:
    #     speak("hello sir, I am friday Tell me what can I do for you ")


    # if hour >= 0 and hour < 12:
    #     print("good morning sir")
    #     speak("good morning sir")
    # elif hour >= 12 and hour < 18:
    #     print("Good Afternoon!")
    #     speak("Good Afternoon!")
    #
    # else:
    #     speak("Good Evening!")
    #
    # print("Hi, I am Edith, please tell me how May I help you!")
#     speak("Hi, I am Edith, please tell me how May I help you!")
#     # current_time = real.strftime("%H:%M")
#     # speak(f"current time is:{current_time}")

class mainT(QThread):
    def __init__(self):
        super(mainT,self).__init__()
    
    def run(self):
        self.JARVIS()

    def takeCommand(self):
        # It takes microphone input from the user and returns string output

        r = sr.Recognizer()
        with sr.Microphone() as source:
            print("Listening...")
            speak("Listening...")
            r.pause_threshold = 1
            audio = r.listen(source)
            try:
                print("Recognizing...")
                speak("Recognizing...")
                query = r.recognize_google(audio, language='en-in')  # Using google for voice recognition.
                print(f"User said: {query}\n")  # User query will be printed.

            except Exception as e:
                # print(e)0
                print("Say that again please...") # Say that again will be printed in case of improper voice
                speak("Say that again please...")
                return "None"  # None string will be returned
            return query

    def JARVIS(self):
       

        while True:
            self.query = self.takeCommand().lower()
            # self.query = self.STT()
            if 'good bye' in self.query:
                sys.exit()

            elif "time" in self.query:
                currenttime()
            elif "open notepad" in self.query:
                path = "C:\\Windows\\System32\\notepad.exe"
                speak("Opening notepad")
                os.startfile(path)
            elif "open command prompt" in self.query:
                speak("opening cmd")
                os.system("start cmd")

            elif "play music" in self.query:
                speak("playing music")
                music_dir = "D:\\music"
                songs = os.listdir(music_dir)
                d = random.choice(songs)
                for song in songs:
                    if song.endswith('.mp3'):
                        os.startfile(os.path.join(music_dir, song))

            elif "ip address" in self.query:
                ip = get('https://api.ipify.org').text
                speak(f"your ip address is{ip}")

            elif "open youtube" in self.query:
                webbrowser.open('www.youtube.com')
            elif "search" in self.query:

                s = self.query
                webbrowser.open(s)
            elif "news" in self.query:
                googlenews()
            elif "on youtube" in self.query:
                speak("playing  on youtube")
                l = self.query

                kit.playonyt(l)
            # elif "email to dhananjay" in self.query:
            #     try:
            #         speak("what should i say")
            #         content = self.takeCommand().lower()
            #         to = "dhananjay93698@gmail.com"
            #         sendEmail(to, content)
            #         speak("email has been sent")
            #     except Exception as e:
            #         print(e)
            #         speak("sorry! email can't be sent")



            elif "jokes " in self.query:
                jokes = pyjokes.get_joke()

            elif "shutdown the system" in self.query:
                speak("shuting down the system")
                os.system("shutdown /s /t 5")
            elif "restart the system" in self.query:
                speak("restarting the system")
                os.system("shutdown /s /t 5")
            elif "sleep the system " in self.query:
                speak("sleep the system")
                os.system("round1132.exe powrprof.dll,SetSuspendState 0,1,0")

            elif "location" in self.query:
                speak("wait sir let me check")
                try:
                    ipadd = requests.get('https://api.ipify.org').text
                    print(ipadd)
                    url = 'https://get.geojs.io/v1/ip/geo/' + ipadd + '.json'
                    geo_request = requests.get(url)
                    geo_data = geo_request.json()
                    city = geo_data['city']
                    country = geo_data['country']
                    speak(f"i am not sure but I thing we are in{city} city of {country}country ")
                except Exception as e:
                    speak("due to network issue I can't find that our  location")

            # elif "no thanks" or "nothing" in query:
            #     speak("thanks! for using me sir")
            #     exit()

            else:

                try:

                    query = self.query.replace("wikipedia", "")
                    results = wikipedia.summary(query, sentences=2)
                    # speak("According to Wikipedia")
                    print(results)
                    speak(results)
                except Exception as e:
                    print("I can't  find please try again")
                    speak("I can't  find please try again")

            speak("sir do you have any other task")
            # if "no thanks" or "nothing" in query:
            #     speak("thanks! for using me sir")
            #     exit()
           # elif 'open google' in self.query:
           #      webbrowser.open('www.google.co.in')
           #      spe ak("opening google")
           #  elif 'open youtube' in self.query:
           #      webbrowser.open("www.youtube.com")
           #  elif 'play music' in self.query:
           #      speak("playing music from pc")
           #      self.music_dir ="./music"
           #      self.musics = os.listdir(self.music_dir)
           #      os.startfile(os.path.join(self.music_dir,self.musics[0]))











FROM_MAIN,_ = loadUiType(os.path.join(os.path.dirname(__file__),"./scifi.ui"))

class Main(QMainWindow,FROM_MAIN):
    def __init__(self,parent=None):
        super(Main,self).__init__(parent)
        self.setupUi(self)
        self.setFixedSize(1920,1080)
        self.label_7 = QLabel
        self.exitB.setStyleSheet("background-image:url(./lib/exit - Copy.png);\n"
        "border:none;")
        self.exitB.clicked.connect(self.close)
        self.setWindowFlags(flags)
        Dspeak = mainT()
        self.label_7 = QMovie("./lib/gifloader.gif", QByteArray(), self)
        self.label_7.setCacheMode(QMovie.CacheAll)
        self.label_4.setMovie(self.label_7)
        self.label_7.start()

        self.ts = time.strftime("%A, %d %B")

        Dspeak.start()
        self.label.setPixmap(QPixmap("./lib/tuse.png"))
        self.label_5.setText("<font size=8 color='white'>"+self.ts+"</font>")
        self.label_5.setFont(QFont(QFont('Acens',8)))


app = QtWidgets.QApplication(sys.argv)
main = Main()
main.show()
exit(app.exec_())